module.exports = {
  NODE_ENV: '"production"',
  BASE_URL:'"/"',
}
